console.log("MY EVENTS JS LOADED");
alert("MY EVENTS JS LOADED");
document.addEventListener("DOMContentLoaded", function () {

    console.log("MY EVENTS JS LOADED");

    const container = document.getElementById("my-events-container");

    if (!container) {
        console.log("Container not found!");
        return;
    }

    const events = JSON.parse(localStorage.getItem("events")) || [];
    const registrations = JSON.parse(localStorage.getItem("registrations")) || [];

    console.log("events:", events);
    console.log("registrations:", registrations);

    const userId = 1;

    const myEventIds = registrations
        .filter(r => Number(r.userId) === userId)
        .map(r => Number(r.eventId));

    console.log("myEventIds:", myEventIds);

    const myEvents = events.filter(e =>
        myEventIds.includes(Number(e.id))
    );

    console.log("myEvents:", myEvents);

    container.innerHTML = "";

    if (myEvents.length === 0) {
        container.innerHTML = "<h2>TEST RENDER</h2>";
        return;
    }

    myEvents.forEach(event => {
        const div = document.createElement("div");

        div.innerHTML = `
            <div style="border:1px solid #ccc; padding:15px; margin:10px; border-radius:8px;">
                <h3>${event.title}</h3>
                <p><b>Club:</b> ${event.club}</p>
                <p><b>Date:</b> ${event.date}</p>
                <p><b>Location:</b> ${event.location}</p>
            </div>
        `;

        container.appendChild(div);
    });

});