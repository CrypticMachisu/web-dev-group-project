
function getRegistrations() {
    return JSON.parse(localStorage.getItem("registrations")) || [];
}

function isSignedUp(eventId) {
    let registrations = getRegistrations();
    let userId = 1;

    return registrations.some(r => r.userId === userId && r.eventId === eventId);
}

function saveSignup(eventId) {
    let registrations = getRegistrations();
    let userId = 1;

    let already = registrations.some(r => r.userId === userId && r.eventId === eventId);

    if (already) {
        alert("You already signed up for this event!");
        return false;
    }

    registrations.push({ userId, eventId });

    localStorage.setItem("registrations", JSON.stringify(registrations));

    return true;
}