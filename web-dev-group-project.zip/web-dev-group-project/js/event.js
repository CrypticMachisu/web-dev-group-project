 <nav style="padding:10px; background:#333; color:white;">
    <a href="index.html" style="color:white; margin-right:15px;">Home</a>
    <a href="event-list.html" style="color:white; margin-right:15px;">Events</a>
    <a href="my-events.html" style="color:white;">My Events</a>
</nav>
 console.log("club-data loaded?");
console.log(typeof clubs);
console.log(typeof events);

 function getEventIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (!id) {
        console.error("No event ID in URL. Use event.html?id=1");
        return 1; // fallback so page doesn't break
    }

    return parseInt(id);
}

function renderEvent() {
    const container = document.getElementById("event-container");

    const eventId = getEventIdFromUrl();

    console.log(eventId);

    const event = events.find(e => e.id === eventId);

    if (!event) {
        container.innerHTML = `
            <p>Event not found.</p>
        `;
        return;
    }

    const club = clubs.find(c => c.id === event.clubId);

    container.innerHTML = `
        <div class="card">
            <h2>${event.title}</h2>

            <p><strong>Club:</strong> ${club.name}</p>
            <p><strong>Date:</strong> ${event.date}</p>
            <p><strong>Location:</strong> ${event.location}</p>

            <p>${event.description}</p>

            ${
    isSignedUp(event.id)
    ? '<button disabled style="background:green;color:white;padding:8px;">Registered</button>'
    : `<button onclick="handleSignup(${event.id})" style="padding:8px;">Sign Up</button>`
}
        </div>
    `;
}

function handleSignup(eventId) {
    if (saveSignup(eventId)) {
        renderEvent();
        alert("Successfully signed up!");
    }
}

document.addEventListener("DOMContentLoaded", renderEvent);