<nav style="padding:10px; background:#333; color:white;">
    <a href="index.html" style="color:white; margin-right:15px;">Home</a>
    <a href="event-list.html" style="color:white; margin-right:15px;">Events</a>
    <a href="my-events.html" style="color:white;">My Events</a>
</nav>
function loadMyClubs() {
    const container = document.getElementById("my-clubs");

    const ids = getMyClubs();

    const myClubs = clubs.filter(c => ids.includes(c.id));

    container.innerHTML = myClubs.length
        ? myClubs.map(c => `<p>${c.name}</p>`).join("")
        : "<p>No clubs joined</p>";
}

loadMyClubs();